import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripCard } from '../trip-card/trip-card';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';
import { ChangeDetectorRef } from '@angular/core';
import { Authentication } from '../services/authentication';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrls: ['./trip-listing.css'],
})
export class TripListing implements OnInit {
  trips: Trip[] = [];
  message: string = '';

  constructor(
    private tripDataService: TripData,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private authentication: Authentication
  ) {
    console.log('trip-listing constructor');
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  private getStuff(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        console.log('Trips returned in Angulajr:', value);
        this.trips = value;
        this.message = value.length > 0
          ? `There are ${value.length} trips available.`
          : 'There were no trips retrieved from the database';

        this.cdr.detectChanges(); // Force angular to update the dang template
      },
      error: (error: any) => {
        console.error('Error fetching trips:', error);
      },
    });
  }

  ngOnInit(): void {
    console.log('trip-listing ngOnInit');
    this.getStuff();
  }

  public isLoggedIn(): boolean {
    return this.authentication.isLoggedIn();
  }

}

import { Injectable, Provider } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpInterceptorFn } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Authentication } from '../services/authentication';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

  constructor(private authentication: Authentication) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    const isAuthAPI =
      request.url.includes('/login') ||
      request.url.includes('/register');

    if (this.authentication.isLoggedIn() && !isAuthAPI) {

      const token = this.authentication.getToken();

      const authReq = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });

      return next.handle(authReq);
    }

    return next.handle(request);
  }

}

 export const authInterceptProvider: Provider =
  {
    provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true };
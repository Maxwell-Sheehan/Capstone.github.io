import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { User } from '../models/user';
import { BROWSER_STORAGE } from '../storage';
import { AuthResponse } from '../models/auth-response';

@Injectable({
  providedIn: 'root',
})
export class TripData {

  private url = 'http://localhost:3000/api/trips';
  baseUrl = 'http://localhost:3000/api';

  constructor (
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url);
  }

  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData);
  }

  getTrip(tripCode: string) : Observable<Trip[]> {
    //console.log('inside tripDataService::getTrips');
    return this.http.get<Trip[]>(this.url + '/' + tripCode);
  }

  updateTrip(formData: Trip) : Observable<Trip> {
    //console.log('inside TripDataService::addTrips');
    return this.http.put<Trip>(this.url + '/' + formData.code, formData);
  }

  login(user: User, passwd: string): Observable<AuthResponse> {
  const formData = {
    email: user.email,
    password: passwd
  };

  return this.http.post<AuthResponse>(
    `${this.baseUrl}/login`,
    formData
  );
}

register(user: User, passwd: string): Observable<AuthResponse> {
  const formData = {
    name: user.name,
    email: user.email,
    password: passwd
  };

  return this.http.post<AuthResponse>(
    `${this.baseUrl}/register`,
    formData
  );
}

}

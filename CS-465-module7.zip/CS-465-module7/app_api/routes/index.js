const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");

router.route("/register").post(authController.register);
router.route("/login").post(authController.login);

router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);

router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip);


// ========================
// JWT Middleware
// ========================
function authenticateJWT(req, res, next) {

    const authHeader = req.headers['authorization'];

    if (!authHeader) return res.sendStatus(401);

    const token = authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        req.auth = verified;
        next();
    } catch (err) {
        return res.sendStatus(403);
    }
}

module.exports = router;
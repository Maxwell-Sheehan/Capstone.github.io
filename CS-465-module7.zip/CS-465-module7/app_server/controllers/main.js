/* GET Homepage */
const index = (req, res) => {
    res.render('Index', { title: "Travlr Getaways"});
};

module.exports = {
    index
}

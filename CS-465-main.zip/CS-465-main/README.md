Architecture

Compare and contrast the types of frontend development you used in your full stack project, including Express HTML, JavaScript, and the single-page application (SPA).
The Express HTML + Java rendering allows the server to generate the full html page, as well as handle the routing processing and requests. SPA is client facing, and can create a much smoother experience for apps and software with frequent refreshes and updates.
With SPA the frontend and backend are decopuled, while with Javascript, the server is handling requests everytime the user interacts.

Why did the backend use a NoSQL MongoDB database?
NoSQL MongoDB is simply very flexible and scalable. The JSON like elements makes adding and editing features very simple, and with a rapidly changing development simpler rewrites is very useful. When adding and testing new featues, it made it feel like we were simply adding more
instead of being forced to rewrite existing work.

Functionality

How is JSON different from Javascript and how does JSON tie together the frontend and backend development pieces?
For one, Javascript is an actual programming language, JSON is a way we format data. JSON allows us to tie our different pieces of a fullstack web server together for this reason. JSON translates requests and data between Node, Angular and MongoDB into ways each language understands
We might make a GET request, and the backend returns trib objects in JSON, and then Angular will map that JSON into trip data to later be rendered from the database.

Provide instances in the full stack process when you refactored code to improve functionality and efficiencies, and name the benefits that come from reusable user interface (UI) components.
In the later stages of development we refactored our code to improve security and have authentication as it's own service. We also seperated the trips into various segments to make UI components easier to interact with, we have trip-listing, and trip-card for instance. This 
made refactoring at later stages of development much easier as you can quickly pinpoint where you need to examine your code in a folder with 70+ files. When the TripCard was rendering two buttons for me to 'edit trip' after adding authentication, I knew exactly where 
to look and resolve the issue in minutes.

Testing



Methods for request and retrieval necessitate various types of API testing of endpoints, in addition to the difficulties of testing with added layers of security. Explain your understanding of methods, endpoints, and security in a full stack application.
In a full stack application we use modern security methods to enable user data is protected as well as our servers. Users have a login, a key assigned to their account when they login that they need to successfully sign on. Their credentials are checked for permissions to make 
sure they can't make server side requests or edits to the application. My understanding of these methods is that by users having these tokens created on sign in, and limiting that tokens lifespan to 1 hour or whatever increment. It prevents user from 'invaded' by someone else
on their machine. We also use the hashing and salt of password and credentials, this is important as it stops us from having sensitve user data in plain text. We as the company don't know the users credentials, and the only way it can be verified is by using the correct string 
in combination with the salt set at creation. This protects the company from important data vulnerabilites as it can be very difficult to brute force user passwords.


Reflection

How has this course helped you in reaching your professional goals? What skills have you learned, developed, or mastered in this course to help you become a more marketable candidate in your career field?
I believe this course was very challenging but very fufilling. Most things in life worth doing aren't easy, and similarly while working through these modules I would sometimes spend hours if not days on problems. The documentation was good, but outdated so in a lot of instances
I had to revise and modernize the syntax and logic of some of the code. Classes would have different names as TripDataServices, was just TripData with the more modern syntax creation. However, despite all this a class has only ever really 'told me' how these services interact
and are used. This course actually showed me how adding a database works, how we test things with API, and these tools that are normally just names actually accomplish things. Using MongoDB and postman as diagnostic toolds when HTMl wasn't rendering properly, or services
werent working correctly had a very practical situation as we were adding features course by course and bulding on exisiting knowledge alwasy towards one goal. I think the knowledge of refactoring code to be more modern is a very marketable skill, as well as having someone
who has deployed a complicated enviornment with APIs, authentication, and databases beyond just their local machine code editor is very significant 
